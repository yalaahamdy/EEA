import os
import base64

def main():
    # المسارات الأساسية
    base_dir = r"d:\Downloads\Downloads\projects\EEA"
    html_path = os.path.join(base_dir, "index.html")
    css_path = os.path.join(base_dir, "css", "styles.css")
    js_bundle_path = os.path.join(base_dir, "js", "bundle.js")
    
    logo_path = os.path.join(base_dir, "icon", "logo.png")
    hero_path = os.path.join(base_dir, "icon", "welcome_hero.webp")
    
    output_path = os.path.join(base_dir, "index_offline.html")

    print("[*] Starting EEA Offline Bundling Process...")

    # 1. قراءة الملفات الأساسية
    if not os.path.exists(html_path):
        print(f"[-] Error: HTML file not found at {html_path}")
        return
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()
        
    if not os.path.exists(css_path):
        print(f"[-] Error: CSS file not found at {css_path}")
        return
    with open(css_path, "r", encoding="utf-8") as f:
        css_content = f.read()
        
    if not os.path.exists(js_bundle_path):
        print(f"[-] Error: JS bundle not found at {js_bundle_path}. Run esbuild first.")
        return
    with open(js_bundle_path, "r", encoding="utf-8") as f:
        js_content = f.read()

    # 2. تحويل الصور إلى Base64 Data URIs
    print("[*] Encoding images into Base64 Data URIs...")
    
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            logo_data = f.read()
            logo_b64 = base64.b64encode(logo_data).decode("utf-8")
            logo_uri = f"data:image/png;base64,{logo_b64}"
            print("[+] Encoded icon/logo.png successfully.")
    else:
        print(f"[-] Warning: logo.png not found at {logo_path}")
        logo_uri = ""
        
    if os.path.exists(hero_path):
        with open(hero_path, "rb") as f:
            hero_data = f.read()
            hero_b64 = base64.b64encode(hero_data).decode("utf-8")
            hero_uri = f"data:image/webp;base64,{hero_b64}"
            print("[+] Encoded icon/welcome_hero.webp successfully.")
    else:
        print(f"[-] Warning: welcome_hero.webp not found at {hero_path}")
        hero_uri = ""

    # 3. دمج الـ CSS والـ JS داخل هيكل الـ HTML باستخدام الاستبدال الحرفي لتجنب أخطاء escape characters
    print("[*] Inlining CSS and JS...")
    
    # استبدال رابط الـ CSS الخارجي بوسم style مدمج
    css_target = '<link rel="stylesheet" href="css/styles.css">'
    style_tag = f"<style>\n{css_content}\n</style>"
    if css_target in html_content:
        html_content = html_content.replace(css_target, style_tag)
        print("[+] Inlined css/styles.css successfully.")
    else:
        # محاولة البحث عن صياغات أخرى لو كان هناك مسافات عشوائية
        html_content = re_fallback_css(html_content, css_content)

    # استبدال وسم الـ JS الخارجي بوسم script مدمج يحتوي على حزمة bundle.js كاملة
    js_target = '<script type="module" src="js/app.js"></script>'
    script_tag = f"<script>\n{js_content}\n</script>"
    if js_target in html_content:
        html_content = html_content.replace(js_target, script_tag)
        print("[+] Inlined js/bundle.js successfully.")
    else:
        html_content = re_fallback_js(html_content, js_content)

    # 4. استبدال مسارات الصور ديناميكياً في الملف المجمع بالكامل
    print("[*] Replacing image paths with Base64 URIs...")
    
    if logo_uri:
        # استبدال logo.png أينما وجد
        html_content = html_content.replace("icon/logo.png", logo_uri)
    if hero_uri:
        # استبدال welcome_hero.webp أينما وجد
        html_content = html_content.replace("icon/welcome_hero.webp", hero_uri)

    # 5. حفظ الملف النهائي المجمع
    print(f"[*] Writing bundled offline file to {output_path}...")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)
        
    print(f"[+] Done! Bundling completed successfully. File size: {os.path.getsize(output_path) / (1024*1024):.2f} MB")

def re_fallback_css(html_content, css_content):
    import re
    # في حال لم يكن التطابق حرفياً، نستخدم استبدالاً يعالج الباك سلاش ككود خام
    css_pattern = re.compile(r'<link\s+rel=["\']stylesheet["\']\s+href=["\']css/styles\.css["\']\s*.*?>|<link\s+href=["\']css/styles\.css["\']\s+rel=["\']stylesheet["\']\s*.*?>', re.IGNORECASE)
    match = css_pattern.search(html_content)
    if match:
        target = match.group(0)
        style_tag = f"<style>\n{css_content}\n</style>"
        html_content = html_content.replace(target, style_tag)
        print("[+] Inlined css/styles.css using fallback regex match.")
    return html_content

def re_fallback_js(html_content, js_content):
    import re
    js_pattern = re.compile(r'<script\s+type=["\']module["\']\s+src=["\']js/app\.js["\']\s*></script>', re.IGNORECASE)
    match = js_pattern.search(html_content)
    if match:
        target = match.group(0)
        script_tag = f"<script>\n{js_content}\n</script>"
        html_content = html_content.replace(target, script_tag)
        print("[+] Inlined js/bundle.js using fallback regex match.")
    return html_content

if __name__ == "__main__":
    main()
