import fs from 'fs';
import path from 'path';

const cssDir = 'd:/Downloads/Downloads/projects/EEA/css';
const stylesPath = path.join(cssDir, 'styles.css');

const filesToMerge = [
  'dashboard.css',
  'roadmap.css',
  'lessons.css',
  'practice.css',
  'quizzes.css',
  'flashcards.css',
  'certificate.css'
];

try {
  console.log('Reading core styles.css...');
  let stylesContent = fs.readFileSync(stylesPath, 'utf8');

  // Remove the @import line for Google Fonts
  console.log('Removing Google Fonts @import...');
  stylesContent = stylesContent.replace(/@import\s+url\([^)]+\);?/g, '');

  let combinedContent = stylesContent + '\n\n';

  // Merge each file
  filesToMerge.forEach(file => {
    const filePath = path.join(cssDir, file);
    console.log(`Merging ${file}...`);
    if (fs.existsSync(filePath)) {
      const fileContent = fs.readFileSync(filePath, 'utf8');
      combinedContent += `\n\n/* ==========================================================================\n   Combined: ${file}\n   ========================================================================== */\n\n`;
      combinedContent += fileContent;
    } else {
      console.warn(`File not found: ${file}`);
    }
  });

  console.log('Writing combined CSS to styles.css...');
  fs.writeFileSync(stylesPath, combinedContent, 'utf8');
  console.log('Combined CSS successfully written!');

  // Delete merged files
  filesToMerge.forEach(file => {
    const filePath = path.join(cssDir, file);
    if (fs.existsSync(filePath)) {
      console.log(`Deleting ${file}...`);
      fs.unlinkSync(filePath);
    }
  });

  console.log('CSS Merge completed successfully!');
} catch (error) {
  console.error('Error during CSS merge:', error);
  process.exit(1);
}
