Add-Type -AssemblyName System.Drawing
$logoPath = "d:\Downloads\Downloads\projects\EEA\icon\logo.png"
$newLogoPath = "d:\Downloads\Downloads\projects\EEA\icon\logo_new.png"

Write-Output "Loading image from $logoPath..."
$img = [System.Drawing.Image]::FromFile($logoPath)
Write-Output "Original size: $($img.Width)x$($img.Height)"

$bmp = New-Object System.Drawing.Bitmap(192, 192)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.DrawImage($img, 0, 0, 192, 192)

$g.Dispose()
$img.Dispose()

Write-Output "Saving compressed image to $newLogoPath..."
$bmp.Save($newLogoPath, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

Write-Output "Replacing original logo..."
Remove-Item $logoPath -Force
Rename-Item $newLogoPath "logo.png"
Write-Output "Done!"
