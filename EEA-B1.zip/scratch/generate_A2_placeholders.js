const fs = require('fs');
const path = require('path');

const baseDir = path.join(__dirname, '../js/data/A2/units');

if (!fs.existsSync(baseDir)) {
  fs.mkdirSync(baseDir, { recursive: true });
}

for (let u = 1; u <= 10; u++) {
  const unitDir = path.join(baseDir, `unit${u}`);
  if (!fs.existsSync(unitDir)) {
    fs.mkdirSync(unitDir, { recursive: true });
  }

  const start = (u - 1) * 4 + 1;
  const end = u * 4;

  for (let l = start; l <= end; l++) {
    const filePath = path.join(unitDir, `lesson${l}.js`);
    const content = `export const lesson${l} = {
  id: ${l},
  unitId: ${u},
  title: "A2 Lesson ${l}",
  description: "Temporary lesson placeholder for Level A2.",
  explanation: {
    intro: "شرح الدرس ${l} للمستوى A2.",
    sections: [
      {
        title: "Introduction",
        content: "Detailed grammar and structure explanation."
      }
    ]
  },
  vocabulary: [],
  dialogue: {
    title: "Lesson Dialogue",
    lines: []
  },
  practice: {
    listening: [],
    speaking: [],
    reading: {
      passage: "This is a reading passage for lesson ${l}.",
      questions: []
    },
    writing: []
  }
};
`;
    fs.writeFileSync(filePath, content, 'utf8');
  }
}

console.log('Successfully generated all 40 A2 placeholder lessons!');
