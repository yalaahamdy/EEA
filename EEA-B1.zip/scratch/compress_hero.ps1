Add-Type -AssemblyName System.Drawing
$heroPath = "d:\Downloads\Downloads\projects\EEA\icon\welcome_hero.png"
$newHeroPath = "d:\Downloads\Downloads\projects\EEA\icon\welcome_hero_new.png"

Write-Output "Loading image from $heroPath..."
$img = [System.Drawing.Image]::FromFile($heroPath)
Write-Output "Original size: $($img.Width)x$($img.Height)"

# We will use 384x384 for a perfect balance of quality and size
$bmp = New-Object System.Drawing.Bitmap(384, 384)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.DrawImage($img, 0, 0, 384, 384)

$g.Dispose()
$img.Dispose()

Write-Output "Saving compressed image to $newHeroPath..."
$bmp.Save($newHeroPath, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

Write-Output "Replacing original hero image..."
Remove-Item $heroPath -Force
Rename-Item $newHeroPath "welcome_hero.png"
Write-Output "Done!"
