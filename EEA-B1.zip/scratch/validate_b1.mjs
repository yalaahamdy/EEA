import { curriculum } from '../js/data/B1/curriculum.js';
console.log('=== START B1 CURRICULUM VALIDATION ===\n');
console.log('Successfully loaded B1 curriculum!');
console.log('Total lessons found:', curriculum.length);

if (curriculum.length !== 100) {
  console.error('Error: Expected 100 lessons in B1 curriculum. Found:', curriculum.length);
  process.exit(1);
}

let errors = 0;
let expectedVocabId = 3811;

const phase6And7Lessons = curriculum.filter(l => l.id >= 81 && l.id <= 100);

phase6And7Lessons.forEach(lesson => {
  console.log(`Checking Lesson ${lesson.id}: "${lesson.title}"`);
  if (!lesson.vocabulary || lesson.vocabulary.length !== 10) {
    console.error(`[ERROR] Lesson ${lesson.id} vocabulary count is ${lesson.vocabulary ? lesson.vocabulary.length : 0} (expected 10).`);
    errors++;
    return;
  }
  
  lesson.vocabulary.forEach(v => {
    if (v.id !== expectedVocabId) {
      console.error(`[ERROR] Word "${v.word}" has ID ${v.id} but expected ${expectedVocabId}.`);
      errors++;
    }
    expectedVocabId++;
  });
});

console.log('\n=== VALIDATION SUMMARY ===');
if (errors === 0) {
  console.log('[SUCCESS] All Phase 6 and 7 lessons (81-100) are fully valid and sequential (Vocab IDs 3811 to 4010)!');
  process.exit(0);
} else {
  console.error(`[FAILURE] Validation failed with ${errors} errors.`);
  process.exit(1);
}
