const fs = require('fs');
const path = require('path');

const unitsDir = path.join(__dirname, '../js/data/A1/units');
let totalErrors = 0;
let validatedLessons = 0;
let validatedQuestions = 0;

console.log('=== START LESSON QUESTIONS ACCURACY VALIDATION ===\n');

for (let u = 1; u <= 10; u++) {
  const unitSubDir = path.join(unitsDir, `unit${u}`);
  
  if (!fs.existsSync(unitSubDir) || !fs.lstatSync(unitSubDir).isDirectory()) {
    console.error(`[ERROR] Unit ${u} subdirectory not found.`);
    totalErrors++;
    continue;
  }

  const lessonFiles = fs.readdirSync(unitSubDir).filter(f => f.startsWith('lesson') && f.endsWith('.js'));
  
  // Sort lessons numerically
  lessonFiles.sort((a, b) => {
    const numA = parseInt(a.replace('lesson', '').replace('.js', ''));
    const numB = parseInt(b.replace('lesson', '').replace('.js', ''));
    return numA - numB;
  });

  lessonFiles.forEach(lFile => {
    const lPath = path.join(unitSubDir, lFile);
    const lContent = fs.readFileSync(lPath, 'utf8');
    
    try {
      const cleanJs = lContent.replace(/export\s+const\s+lesson\d+\s*=\s*/, '').trim().replace(/;$/, '');
      const lesson = eval(`(${cleanJs})`);
      validatedLessons++;

      if (lesson.practice) {
        // 1. Validate Listening Exercises
        if (Array.isArray(lesson.practice.listening)) {
          lesson.practice.listening.forEach((q, qIdx) => {
            validatedQuestions++;
            const prefix = `[Listening Ex ${qIdx + 1}] in ${lFile}`;
            
            // Check options
            if (!Array.isArray(q.options) || q.options.length === 0) {
              console.error(`   [ERROR] ${prefix}: Options are missing or not an array.`);
              totalErrors++;
              return;
            }
            
            // Check answer presence in options
            const cleanOptions = q.options.map(o => o.toLowerCase().trim());
            const cleanAnswer = q.answer.toLowerCase().trim();
            if (!cleanOptions.includes(cleanAnswer)) {
              console.error(`   [ERROR] ${prefix}: Correct answer "${q.answer}" is NOT present in options [${q.options.join(', ')}].`);
              totalErrors++;
            }

            // Check duplicates in options
            const hasDuplicates = new Set(cleanOptions).size !== cleanOptions.length;
            if (hasDuplicates) {
              console.warn(`   [WARNING] ${prefix}: Options contain duplicate values: [${q.options.join(', ')}].`);
            }
          });
        }

        // 2. Validate Reading Exercises
        if (lesson.practice.reading && Array.isArray(lesson.practice.reading.questions)) {
          lesson.practice.reading.questions.forEach((q, qIdx) => {
            validatedQuestions++;
            const prefix = `[Reading Q ${qIdx + 1}] in ${lFile}`;
            
            if (!Array.isArray(q.options) || q.options.length === 0) {
              console.error(`   [ERROR] ${prefix}: Options are missing or not an array.`);
              totalErrors++;
              return;
            }

            const cleanOptions = q.options.map(o => o.toLowerCase().trim());
            const cleanAnswer = q.answer.toLowerCase().trim();
            if (!cleanOptions.includes(cleanAnswer)) {
              console.error(`   [ERROR] ${prefix}: Correct answer "${q.answer}" is NOT present in options [${q.options.join(', ')}].`);
              totalErrors++;
            }

            const hasDuplicates = new Set(cleanOptions).size !== cleanOptions.length;
            if (hasDuplicates) {
              console.warn(`   [WARNING] ${prefix}: Options contain duplicate values: [${q.options.join(', ')}].`);
            }
          });
        }

        // 3. Validate Writing Exercises
        if (Array.isArray(lesson.practice.writing)) {
          lesson.practice.writing.forEach((q, qIdx) => {
            validatedQuestions++;
            const prefix = `[Writing Ex ${qIdx + 1}] in ${lFile}`;
            
            // If fill in the blank (has placeholder and answer)
            if (q.answer) {
              if (q.placeholder) {
                // If options are in the placeholder (comma/slash separated)
                const optionsPool = q.placeholder.split(/[\/\,]/).map(o => o.trim().toLowerCase());
                const cleanAnswer = q.answer.toLowerCase().trim();
                
                if (optionsPool.length > 1 && !optionsPool.includes(cleanAnswer)) {
                  console.error(`   [ERROR] ${prefix} (Blank): Correct answer "${q.answer}" is NOT present in placeholder options [${q.placeholder}].`);
                  totalErrors++;
                }
              }
            } else if (q.correct) {
              // Sentence translator scramble
              if (!Array.isArray(q.correct) || q.correct.length === 0) {
                console.error(`   [ERROR] ${prefix} (Scramble): Correct words array is missing or empty.`);
                totalErrors++;
              }
            }
          });
        }
      }

      // 4. Validate quiz (if exists)
      if (Array.isArray(lesson.quiz)) {
        lesson.quiz.forEach((q, qIdx) => {
          validatedQuestions++;
          const prefix = `[Quiz Q ${qIdx + 1}] in ${lFile}`;
          
          if (Array.isArray(q.options)) {
            const cleanOptions = q.options.map(o => o.toLowerCase().trim());
            const cleanAnswer = q.answer.toLowerCase().trim();
            if (!cleanOptions.includes(cleanAnswer)) {
              console.error(`   [ERROR] ${prefix}: Correct answer "${q.answer}" is NOT present in options [${q.options.join(', ')}].`);
              totalErrors++;
            }
          }
        });
      }

    } catch (err) {
      console.error(`[CRITICAL ERROR] Failed to parse or eval ${lFile}:`, err.message);
      totalErrors++;
    }
  });
}

console.log('\n=== QUESTIONS VALIDATION SUMMARY ===');
console.log(`Lessons Inspected: ${validatedLessons} / 40`);
console.log(`Total Individual Questions Inspected: ${validatedQuestions}`);
console.log(`Total Validation Errors: ${totalErrors}`);

if (totalErrors === 0) {
  console.log('\n[SUCCESS] All questions options and answers are fully consistent and error-free!');
  process.exit(0);
} else {
  console.error(`\n[FAILURE] Found ${totalErrors} inconsistencies or errors in questions data.`);
  process.exit(1);
}
