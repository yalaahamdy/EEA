const fs = require('fs');
const path = require('path');

const unitsDir = path.join(__dirname, '../js/data/units');
const files = fs.readdirSync(unitsDir).filter(f => f.startsWith('unit') && f.endsWith('.js'));

// Sort files numerically unit1, unit2 ... unit10
files.sort((a, b) => {
  const numA = parseInt(a.replace('unit', '').replace('.js', ''));
  const numB = parseInt(b.replace('unit', '').replace('.js', ''));
  return numA - numB;
});

files.forEach(file => {
  const filePath = path.join(unitsDir, file);
  // We can require it or parse it as JSON if it's JSON-like, but it's JS module.
  // Let's parse it using regex or load it simply by reading content and extracting JSON parts.
  const content = fs.readFileSync(filePath, 'utf8');
  
  // Extract unit id and title
  const unitTitleMatch = content.match(/"title":\s*"([^"]+)"/);
  const unitTitle = unitTitleMatch ? unitTitleMatch[1] : 'Unknown Unit';
  console.log(`\n=== ${unitTitle} (${file}) ===`);
  
  // Extract lessons
  // A simple parser using regex for lessons
  const lessonRegex = /"id":\s*(\d+),\s*"unitId":\s*\d+,\s*"title":\s*"([^"]+)"/g;
  let match;
  while ((match = lessonRegex.exec(content)) !== null) {
    console.log(`   Lesson ${match[1]}: ${match[2]}`);
  }
});
