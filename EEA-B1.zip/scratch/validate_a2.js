import { curriculum } from '../js/data/A2/curriculum.js';

console.log("=== بدء عملية فحص جودة وتكامل منهج A2 ===");

let errors = [];
let totalVocab = 0;

if (!curriculum || curriculum.length === 0) {
  console.error("خطأ: لم يتم تحميل المنهج بشكل صحيح أو أنه فارغ!");
  process.exit(1);
}

if (curriculum.length !== 40) {
  errors.push(`عدد الدروس في المنهج هو ${curriculum.length} بدلاً من 40 درس.`);
}

curriculum.forEach((lesson, index) => {
  const lessonNum = index + 1;
  
  if (!lesson) {
    errors.push(`الدرس ${lessonNum}: غير موجود أو لم يتم استيراده.`);
    return;
  }

  // 1. فحص المعرف والوحدة والعنوان والوصف
  if (lesson.id !== lessonNum) {
    errors.push(`الدرس ${lessonNum}: المعرف المكتوب هو ${lesson.id} بدلاً من ${lessonNum}.`);
  }
  if (!lesson.title || lesson.title.trim() === "") {
    errors.push(`الدرس ${lessonNum}: العنوان فارغ.`);
  }
  if (!lesson.description || lesson.description.trim() === "") {
    errors.push(`الدرس ${lessonNum}: الوصف فارغ.`);
  }

  // 2. فحص الشرح
  if (!lesson.explanation) {
    errors.push(`الدرس ${lessonNum}: كائن الشرح (explanation) غير موجود.`);
  } else {
    if (!lesson.explanation.intro || lesson.explanation.intro.trim() === "") {
      errors.push(`الدرس ${lessonNum}: مقدمة الشرح فارغة.`);
    }
    if (!lesson.explanation.sections || !Array.isArray(lesson.explanation.sections) || lesson.explanation.sections.length === 0) {
      errors.push(`الدرس ${lessonNum}: أقسام الشرح فارغة أو ليست مصفوفة.`);
    } else {
      lesson.explanation.sections.forEach((sec, sIdx) => {
        if (!sec.title || sec.title.trim() === "") {
          errors.push(`الدرس ${lessonNum} - قسم الشرح ${sIdx+1}: العنوان فارغ.`);
        }
        if (!sec.content || sec.content.trim() === "") {
          errors.push(`الدرس ${lessonNum} - قسم الشرح ${sIdx+1}: المحتوى فارغ.`);
        }
      });
    }
  }

  // 3. فحص المفردات
  if (!lesson.vocabulary || !Array.isArray(lesson.vocabulary)) {
    errors.push(`الدرس ${lessonNum}: المفردات غير موجودة أو ليست مصفوفة.`);
  } else {
    totalVocab += lesson.vocabulary.length;
    if (lesson.vocabulary.length !== 30) {
      errors.push(`الدرس ${lessonNum}: يحتوي على ${lesson.vocabulary.length} مفردات بدلاً من 30.`);
    }
    lesson.vocabulary.forEach((vocab, vIdx) => {
      if (!vocab.id) {
        errors.push(`الدرس ${lessonNum} - المفردة ${vIdx+1}: المعرف غير موجود.`);
      }
      if (!vocab.word || vocab.word.trim() === "") {
        errors.push(`الدرس ${lessonNum} - المفردة ${vIdx+1}: الكلمة الإنجليزية فارغة.`);
      }
      if (!vocab.translation || vocab.translation.trim() === "") {
        errors.push(`الدرس ${lessonNum} - المفردة ${vIdx+1}: الترجمة العربية فارغة.`);
      }
      if (!vocab.example || vocab.example.trim() === "") {
        errors.push(`الدرس ${lessonNum} - المفردة ${vIdx+1}: المثال الإنجليزي فارغ.`);
      }
      if (!vocab.exampleTranslation || vocab.exampleTranslation.trim() === "") {
        errors.push(`الدرس ${lessonNum} - المفردة ${vIdx+1}: ترجمة المثال فارغة.`);
      }
    });
  }

  // 4. فحص الحوار
  if (!lesson.dialogue) {
    errors.push(`الدرس ${lessonNum}: الحوار غير موجود.`);
  } else {
    if (!lesson.dialogue.title || lesson.dialogue.title.trim() === "") {
      errors.push(`الدرس ${lessonNum}: عنوان الحوار فارغ.`);
    }
    if (!lesson.dialogue.lines || !Array.isArray(lesson.dialogue.lines) || lesson.dialogue.lines.length === 0) {
      errors.push(`الدرس ${lessonNum}: أسطر الحوار فارغة أو ليست مصفوفة.`);
    } else {
      lesson.dialogue.lines.forEach((line, lIdx) => {
        if (!line.speaker || line.speaker.trim() === "") {
          errors.push(`الدرس ${lessonNum} - سطر الحوار ${lIdx+1}: المتحدث فارغ.`);
        }
        if (!line.text || line.text.trim() === "") {
          errors.push(`الدرس ${lessonNum} - سطر الحوار ${lIdx+1}: النص الإنجليزي فارغ.`);
        }
        if (!line.translation || line.translation.trim() === "") {
          errors.push(`الدرس ${lessonNum} - سطر الحوار ${lIdx+1}: الترجمة العربية فارغة.`);
        }
      });
    }
  }

  // 5. فحص التمارين (Practice)
  if (!lesson.practice) {
    errors.push(`الدرس ${lessonNum}: كائن التدريب غير موجود.`);
  } else {
    // تمرين الاستماع
    if (!lesson.practice.listening || !Array.isArray(lesson.practice.listening) || lesson.practice.listening.length !== 3) {
      errors.push(`الدرس ${lessonNum}: تمرين الاستماع لا يحتوي على 3 أسئلة.`);
    } else {
      lesson.practice.listening.forEach((q, qIdx) => {
        if (!q.text || q.text.trim() === "") {
          errors.push(`الدرس ${lessonNum} - الاستماع ${qIdx+1}: النص فارغ.`);
        }
        if (!q.options || !Array.isArray(q.options) || q.options.length === 0) {
          errors.push(`الدرس ${lessonNum} - الاستماع ${qIdx+1}: الخيارات فارغة.`);
        }
        if (!q.answer || q.answer.trim() === "") {
          errors.push(`الدرس ${lessonNum} - الاستماع ${qIdx+1}: الإجابة الصحيحة فارغة.`);
        }
        if (!q.hint || q.hint.trim() === "") {
          errors.push(`الدرس ${lessonNum} - الاستماع ${qIdx+1}: التلميح فارغ.`);
        }
      });
    }

    // تمرين التحدث
    if (!lesson.practice.speaking || !Array.isArray(lesson.practice.speaking) || lesson.practice.speaking.length < 2) {
      errors.push(`الدرس ${lessonNum}: تمرين التحدث يحتوي على أقل من جملتين.`);
    } else {
      lesson.practice.speaking.forEach((s, sIdx) => {
        if (!s.text || s.text.trim() === "") {
          errors.push(`الدرس ${lessonNum} - التحدث ${sIdx+1}: النص فارغ.`);
        }
        if (!s.translation || s.translation.trim() === "") {
          errors.push(`الدرس ${lessonNum} - التحدث ${sIdx+1}: الترجمة فارغة.`);
        }
      });
    }

    // تمرين القراءة
    if (!lesson.practice.reading) {
      errors.push(`الدرس ${lessonNum}: تمرين القراءة غير موجود.`);
    } else {
      if (!lesson.practice.reading.passage || lesson.practice.reading.passage.trim() === "") {
        errors.push(`الدرس ${lessonNum}: قطعة القراءة فارغة.`);
      }
      if (!lesson.practice.reading.questions || !Array.isArray(lesson.practice.reading.questions) || lesson.practice.reading.questions.length < 2) {
        errors.push(`الدرس ${lessonNum}: أسئلة القراءة أقل من سؤالين.`);
      } else {
        lesson.practice.reading.questions.forEach((q, qIdx) => {
          if (!q.q || q.q.trim() === "") {
            errors.push(`الدرس ${lessonNum} - سؤال القراءة ${qIdx+1}: السؤال فارغ.`);
          }
          if (!q.options || !Array.isArray(q.options) || q.options.length === 0) {
            errors.push(`الدرس ${lessonNum} - سؤال القراءة ${qIdx+1}: الخيارات فارغة.`);
          }
          if (!q.answer || q.answer.trim() === "") {
            errors.push(`الدرس ${lessonNum} - سؤال القراءة ${qIdx+1}: الإجابة فارغة.`);
          }
          if (!q.explanation || q.explanation.trim() === "") {
            errors.push(`الدرس ${lessonNum} - سؤال القراءة ${qIdx+1}: التفسير فارغ.`);
          }
        });
      }
    }

    // تمرين الكتابة
    if (!lesson.practice.writing || !Array.isArray(lesson.practice.writing) || lesson.practice.writing.length < 2) {
      errors.push(`الدرس ${lessonNum}: تمرين الكتابة يحتوي على أقل من تمرينين.`);
    } else {
      lesson.practice.writing.forEach((w, wIdx) => {
        if (!w.prompt || w.prompt.trim() === "") {
          errors.push(`الدرس ${lessonNum} - الكتابة ${wIdx+1}: موجه السؤال (prompt) فارغ.`);
        }
        // يمكن أن يكون تمرين ترتيب كلمات (يحتوي على words و correct) أو إكمال فراغ (يحتوي على placeholder و answer)
        if (!w.correct && !w.answer) {
          errors.push(`الدرس ${lessonNum} - الكتابة ${wIdx+1}: لا يحتوي على إجابة صحيحة (correct أو answer).`);
        }
      });
    }
  }
});

console.log(`إجمالي الكلمات المكتشفة: ${totalVocab} كلمة.`);

if (errors.length > 0) {
  console.error(`تم العثور على ${errors.length} خطأ في جودة المنهج:`);
  errors.forEach(err => console.error(`- ${err}`));
  process.exit(1);
} else {
  console.log("نجاح: جميع ملفات الدروس الأربعين لـ A2 مطابقة تماماً للمواصفات وخالية من الأخطاء!");
  process.exit(0);
}
