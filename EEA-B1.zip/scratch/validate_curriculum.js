const fs = require('fs');
const path = require('path');

const unitsDir = path.join(__dirname, '../js/data/A1/units');
let totalErrors = 0;
let totalWarnings = 0;
let validatedLessons = 0;
let totalVocab = 0;
const wordMap = new Map();

console.log('=== START CURRICULUM DATA QUALITY VALIDATION ===\n');

for (let u = 1; u <= 10; u++) {
  const unitSubDir = path.join(unitsDir, `unit${u}`);
  
  if (!fs.existsSync(unitSubDir) || !fs.lstatSync(unitSubDir).isDirectory()) {
    console.error(`[ERROR] Unit ${u} subdirectory not found.`);
    totalErrors++;
    continue;
  }

  // Read lessons from subdirectory
  const lessonFiles = fs.readdirSync(unitSubDir).filter(f => f.startsWith('lesson') && f.endsWith('.js'));
  
  if (lessonFiles.length !== 4) {
    console.error(`[ERROR] Unit ${u} must contain exactly 4 lessons. Found: ${lessonFiles.length}`);
    totalErrors++;
  }

  // Sort lessons numerically
  lessonFiles.sort((a, b) => {
    const numA = parseInt(a.replace('lesson', '').replace('.js', ''));
    const numB = parseInt(b.replace('lesson', '').replace('.js', ''));
    return numA - numB;
  });

  lessonFiles.forEach(lFile => {
    const lPath = path.join(unitSubDir, lFile);
    const lContent = fs.readFileSync(lPath, 'utf8');
    
    try {
      const cleanJs = lContent.replace(/export\s+const\s+lesson\d+\s*=\s*/, '').trim().replace(/;$/, '');
      const lesson = eval(`(${cleanJs})`);
      validatedLessons++;

      // 1. Basic Structure Validation
      if (typeof lesson.id !== 'number') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid lesson ID.`);
        totalErrors++;
      }
      if (!lesson.title || typeof lesson.title !== 'string') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid title.`);
        totalErrors++;
      }
      if (!lesson.description || typeof lesson.description !== 'string') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid description.`);
        totalErrors++;
      }

      // 2. Explanation Validation
      if (!lesson.explanation || typeof lesson.explanation !== 'object') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid explanation object.`);
        totalErrors++;
      } else {
        if (!lesson.explanation.intro) {
          console.error(`   [ERROR] ${lFile}: Missing explanation intro.`);
          totalErrors++;
        }
        if (!Array.isArray(lesson.explanation.sections) || lesson.explanation.sections.length === 0) {
          console.error(`   [ERROR] ${lFile}: Missing or empty explanation sections.`);
          totalErrors++;
        } else {
          lesson.explanation.sections.forEach((sec, sIdx) => {
            if (!sec.title || !sec.content) {
              console.error(`   [ERROR] ${lFile}: Section ${sIdx + 1} is missing title or content.`);
              totalErrors++;
            }
          });
        }
      }

      // 3. Vocabulary Validation
      if (!Array.isArray(lesson.vocabulary) || lesson.vocabulary.length === 0) {
        console.error(`   [ERROR] ${lFile}: Missing or empty vocabulary array.`);
        totalErrors++;
      } else {
        totalVocab += lesson.vocabulary.length;
        lesson.vocabulary.forEach((v, vIdx) => {
          if (!v.id || typeof v.id !== 'number') {
            console.error(`   [ERROR] ${lFile}: Vocabulary word at index ${vIdx} is missing a numeric ID.`);
            totalErrors++;
          }
          if (!v.word || typeof v.word !== 'string') {
            console.error(`   [ERROR] ${lFile}: Vocabulary word at index ${vIdx} is missing spelling.`);
            totalErrors++;
          } else {
            const wordKey = v.word.toLowerCase().trim();
            if (wordMap.has(wordKey)) {
              wordMap.get(wordKey).push({ unit: u, lesson: lesson.id });
            } else {
              wordMap.set(wordKey, [{ unit: u, lesson: lesson.id }]);
            }
          }
          if (!v.translation || typeof v.translation !== 'string') {
            console.error(`   [ERROR] ${lFile}: Word "${v.word || vIdx}" is missing translation.`);
            totalErrors++;
          }
          if (!v.example || typeof v.example !== 'string') {
            console.error(`   [ERROR] ${lFile}: Word "${v.word || vIdx}" is missing example sentence.`);
            totalErrors++;
          }
          if (!v.exampleTranslation || typeof v.exampleTranslation !== 'string') {
            console.error(`   [ERROR] ${lFile}: Word "${v.word || vIdx}" is missing example translation.`);
            totalErrors++;
          }
        });
      }

      // 4. Dialogue Validation
      if (!lesson.dialogue || typeof lesson.dialogue !== 'object') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid dialogue object.`);
        totalErrors++;
      } else {
        if (!lesson.dialogue.title) {
          console.error(`   [ERROR] ${lFile}: Dialogue is missing a title.`);
          totalErrors++;
        }
        if (!Array.isArray(lesson.dialogue.lines) || lesson.dialogue.lines.length === 0) {
          console.error(`   [ERROR] ${lFile}: Dialogue lines are empty or invalid.`);
          totalErrors++;
        } else {
          lesson.dialogue.lines.forEach((ln, lIdx) => {
            if (!ln.speaker || !ln.text || !ln.translation) {
              console.error(`   [ERROR] ${lFile}: Dialogue line ${lIdx + 1} has missing speaker, text, or translation.`);
              totalErrors++;
            }
          });
        }
      }

      // 5. Practice & Exercises Validation
      if (!lesson.practice || typeof lesson.practice !== 'object') {
        console.error(`   [ERROR] ${lFile}: Missing or invalid practice object.`);
        totalErrors++;
      } else {
        // Listening
        if (!Array.isArray(lesson.practice.listening) || lesson.practice.listening.length === 0) {
          console.error(`   [ERROR] ${lFile}: Listening practice is empty.`);
          totalErrors++;
        } else {
          lesson.practice.listening.forEach((q, qIdx) => {
            if (!q.text || !Array.isArray(q.options) || !q.answer || !q.hint) {
              console.error(`   [ERROR] ${lFile}: Listening question ${qIdx + 1} is missing text, options, answer, or hint.`);
              totalErrors++;
            }
          });
        }

        // Speaking
        if (!Array.isArray(lesson.practice.speaking) || lesson.practice.speaking.length === 0) {
          console.error(`   [ERROR] ${lFile}: Speaking practice is empty.`);
          totalErrors++;
        } else {
          lesson.practice.speaking.forEach((q, qIdx) => {
            if (!q.text || !q.translation) {
              console.error(`   [ERROR] ${lFile}: Speaking item ${qIdx + 1} is missing text or translation.`);
              totalErrors++;
            }
          });
        }

        // Reading
        const rd = lesson.practice.reading;
        if (!rd || typeof rd !== 'object') {
          console.error(`   [ERROR] ${lFile}: Reading practice object is missing.`);
          totalErrors++;
        } else {
          const passageText = rd.passage || rd.text;
          if (!passageText) {
            console.error(`   [ERROR] ${lFile}: Reading passage is missing.`);
            totalErrors++;
          }
          if (!Array.isArray(rd.questions) || rd.questions.length === 0) {
            console.error(`   [ERROR] ${lFile}: Reading questions are missing or empty.`);
            totalErrors++;
          } else {
            rd.questions.forEach((q, qIdx) => {
              if (!q.q || !Array.isArray(q.options) || !q.answer || !q.explanation) {
                console.error(`   [ERROR] ${lFile}: Reading question ${qIdx + 1} is missing q, options, answer, or explanation.`);
                totalErrors++;
              }
            });
          }
        }

        // Writing
        if (!Array.isArray(lesson.practice.writing) || lesson.practice.writing.length === 0) {
          console.error(`   [ERROR] ${lFile}: Writing practice is empty.`);
          totalErrors++;
        } else {
          lesson.practice.writing.forEach((q, qIdx) => {
            if (!q.prompt) {
              console.error(`   [ERROR] ${lFile}: Writing item ${qIdx + 1} is missing prompt.`);
              totalErrors++;
            }
            if (!q.words && !q.placeholder) {
              console.error(`   [ERROR] ${lFile}: Writing item ${qIdx + 1} needs either 'words' or 'placeholder'.`);
              totalErrors++;
            }
            if (!q.correct && !q.answer) {
              console.error(`   [ERROR] ${lFile}: Writing item ${qIdx + 1} needs either 'correct' array or 'answer'.`);
              totalErrors++;
            }
          });
        }
      }

    } catch (err) {
      console.error(`[CRITICAL ERROR] Failed to parse ${lFile}:`, err.message);
      totalErrors++;
    }
  });
}

console.log('\n=== VALIDATION SUMMARY ===');
console.log(`Lessons Validated: ${validatedLessons} / 40`);
console.log(`Total Vocabulary Words Found: ${totalVocab}`);
console.log(`Unique Vocabulary Words: ${wordMap.size}`);

// Check duplicates
let duplicateCount = 0;
for (const [word, occurrences] of wordMap.entries()) {
  if (occurrences.length > 1) {
    duplicateCount++;
  }
}
console.log(`Total Duplicate Words: ${duplicateCount}`);
console.log(`Total Validation Errors: ${totalErrors}`);
console.log(`Total Validation Warnings: ${totalWarnings}`);

if (totalErrors === 0) {
  console.log('\n[SUCCESS] Curriculum data is healthy and ready for production!');
  process.exit(0);
} else {
  console.error(`\n[FAILURE] Found ${totalErrors} errors during curriculum data validation.`);
  process.exit(1);
}
