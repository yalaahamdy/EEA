const fs = require('fs');
const path = require('path');

const unitsDir = path.join(__dirname, '../js/data/units');

for (let i = 1; i <= 10; i++) {
  const filePath = path.join(unitsDir, `unit${i}.js`);
  if (!fs.existsSync(filePath)) {
    console.log(`File not found: ${filePath}`);
    continue;
  }
  
  console.log(`Processing ${filePath}...`);
  let content = fs.readFileSync(filePath, 'utf8');
  
  let cleanedContent = content;
  let index = cleanedContent.indexOf('"quiz": [');
  while (index !== -1) {
    let bracketCount = 1;
    let endIdx = -1;
    for (let j = index + 9; j < cleanedContent.length; j++) {
      if (cleanedContent[j] === '[') {
        bracketCount++;
      } else if (cleanedContent[j] === ']') {
        bracketCount--;
        if (bracketCount === 0) {
          endIdx = j;
          break;
        }
      }
    }
    
    if (endIdx !== -1) {
      let sliceStart = index;
      let sliceEnd = endIdx + 1;
      
      let tempStart = sliceStart - 1;
      while (tempStart > 0 && /\s/.test(cleanedContent[tempStart])) {
        tempStart--;
      }
      if (cleanedContent[tempStart] === ',') {
        sliceStart = tempStart;
      } else {
        let tempEnd = sliceEnd;
        while (tempEnd < cleanedContent.length && /\s/.test(cleanedContent[tempEnd])) {
          tempEnd++;
        }
        if (cleanedContent[tempEnd] === ',') {
          sliceEnd = tempEnd + 1;
        }
      }
      
      cleanedContent = cleanedContent.substring(0, sliceStart) + cleanedContent.substring(sliceEnd);
    } else {
      break;
    }
    
    index = cleanedContent.indexOf('"quiz": [');
  }
  
  fs.writeFileSync(filePath, cleanedContent, 'utf8');
  console.log(`Cleaned ${filePath} successfully.`);
}
console.log("Cleanup script completed!");
